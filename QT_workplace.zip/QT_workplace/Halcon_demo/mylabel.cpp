#include "mylabel.h"
#include <QMouseEvent>

//QWidget默认是不追踪鼠标事件的

MyLabel::MyLabel(QWidget *parent) : QLabel(parent)
{
    // 设置窗口追踪鼠标键
    this->setMouseTracking(true);
}

void MyLabel::mouseMoveEvent(QMouseEvent *ev){

    QString str = QString("坐标值为: (%1, %2)").arg(ev->x()).arg(ev->y());
    setText(str);
}
