#include "mylabel.h"
#include <QMouseEvent>
#include <QTimer>


//QWidget默认是不追踪鼠标事件的

MyLabel::MyLabel(QWidget *parent) : QLabel(parent)
{
    // 设置窗口追踪鼠标键
    this->setMouseTracking(true);

    //启动定时器，参数1是触发时间，单位为ms，其他参数不用设置
    // 第一种定时器写法
    id = startTimer(100);  // 这里触发时间其实就可以规定计时的单位是分钟秒钟还是毫秒，后续可打印到屏幕上

    // 第二种定时器写法
    QTimer* timer = new QTimer(this);
    timer->start(100);
    connect(timer, &QTimer::timeout, this, [=](){
        static int num = 0;
        QString str = QString("%1: %2").arg("time").arg(num++);
        setText(str);
        if(num == 101){
            timer->stop();
        }
    });

}

void MyLabel::enterEvent(QEvent *){
    this->setText("不洗头！");
}

void MyLabel::leaveEvent(QEvent *){

    this->setText("不吃饭！喝露水！");
}

void MyLabel::mousePressEvent(QMouseEvent *ev){

    // 字符串拼接 QString().arg()
    // %1,%2,%3是占位符
    QString btn;
    if(ev->button() == Qt::LeftButton){
        btn = "LeftButton";
    }
    if(ev->button() == Qt::RightButton){
        btn = "RightButton";
    }
    QString str = QString("MousePress[%3]: (%1, %2)").arg(ev->x()).arg(ev->y()).arg(btn);
    setText(str);
}

void MyLabel::mouseReleaseEvent(QMouseEvent *ev){

    QString btn;
    if(ev->button() == Qt::LeftButton){
        btn = "LeftButton";
    }
    if(ev->button() == Qt::RightButton){
        btn = "RightButton";
    }
    QString str = QString("MouseRelease[%3]: (%1, %2)").arg(ev->x()).arg(ev->y()).arg(btn);
    setText(str);

}

void MyLabel::mouseMoveEvent(QMouseEvent *ev){

    QString btn;
    if(ev->buttons() & Qt::LeftButton){
        btn = "LeftButton";
    }
    if(ev->buttons() & Qt::RightButton){
        btn = "RightButton";
    }
    QString str = QString("MouseMove[%3]: (%1, %2)").arg(ev->x()).arg(ev->y()).arg(btn);
    setText(str);
}


// 每触发一次定时器，进入该函数中
void MyLabel::timerEvent(QTimerEvent *e){
    if(e->timerId()==id){
        static int num = 0;  // 必须是static
        QString str = QString("%1: %2").arg("timer").arg(num++);
        setText(str);
        if(num == 101){
            killTimer(id);
        }
    }

}
