#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPixmap *pixmap = new QPixmap("C:\\Users\\94960\\Desktop\\JISOO\\7080ab5bgy1gs9dm8cl69j20j60nwn4c.jpg");
    pixmap->scaled(ui->label_2->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
    ui->label_2->setScaledContents(true);
    ui->label_2->setPixmap(*pixmap);
}

MainWindow::~MainWindow()
{
    delete ui;
}
